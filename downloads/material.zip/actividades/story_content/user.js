function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6iA4mS9yz6U":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

